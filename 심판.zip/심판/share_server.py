#!/usr/bin/env python3
"""Serve only the public referee app files on the loopback interface."""

import argparse
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlsplit


ROOT = Path(__file__).resolve().parent
PUBLIC_FILES = {
    "/": ("index.html", "text/html; charset=utf-8"),
    "/index.html": ("index.html", "text/html; charset=utf-8"),
    "/styles.css": ("styles.css", "text/css; charset=utf-8"),
    "/app.js": ("app.js", "text/javascript; charset=utf-8"),
    "/csv.js": ("csv.js", "text/javascript; charset=utf-8"),
    "/assets/intrusion.mp3": ("assets/intrusion.mp3", "audio/mpeg"),
    "/assets/intrusion-female.mp3": ("assets/intrusion-female.mp3", "audio/mpeg"),
    "/assets/intrusion-male.mp3": ("assets/intrusion-male.mp3", "audio/mpeg"),
}


class ShareHandler(BaseHTTPRequestHandler):
    def do_GET(self):
        self._serve_file(include_body=True)

    def do_HEAD(self):
        self._serve_file(include_body=False)

    def _serve_file(self, include_body):
        try:
            public_file = PUBLIC_FILES.get(urlsplit(self.path).path)
        except ValueError:
            public_file = None
        if public_file is None:
            self.send_error(404)
            return

        relative_path, content_type = public_file
        file_path = (ROOT / relative_path).resolve()
        if not file_path.is_relative_to(ROOT):
            self.send_error(404)
            return
        try:
            content = file_path.read_bytes()
        except OSError:
            self.send_error(404)
            return

        self.send_response(200)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(content)))
        self.send_header("Cache-Control", "no-cache")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.end_headers()
        if include_body:
            self.wfile.write(content)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--port", type=int, default=8766)
    args = parser.parse_args()
    with ThreadingHTTPServer(("127.0.0.1", args.port), ShareHandler) as server:
        print(f"Serving public app files at http://127.0.0.1:{server.server_port}", flush=True)
        try:
            server.serve_forever()
        except KeyboardInterrupt:
            pass


if __name__ == "__main__":
    main()
