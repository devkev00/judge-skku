(() => {
  "use strict";

  const HEADERS = ["구분", "총 팀 수", "팀", "침범 횟수", "판정 번호", "판정 시각", "경기 시작", "집계 시각"];
  const pad = (value, width = 2) => String(value).padStart(width, "0");

  function dateParts(timestamp) {
    if (timestamp === null || timestamp === undefined) return null;
    const date = new Date(timestamp);
    if (!Number.isSafeInteger(timestamp) || !Number.isFinite(date.getTime())) {
      throw new TypeError("유효하지 않은 판정 시각입니다.");
    }
    return [
      pad(date.getFullYear(), 4), pad(date.getMonth() + 1), pad(date.getDate()),
      pad(date.getHours()), pad(date.getMinutes()), pad(date.getSeconds()), pad(date.getMilliseconds(), 3),
    ];
  }

  function formatDate(timestamp) {
    const parts = dateParts(timestamp);
    if (!parts) return "";
    const [year, month, day, hour, minute, second, millisecond] = parts;
    return `${year}-${month}-${day} ${hour}:${minute}:${second}.${millisecond}`;
  }

  function cell(value) {
    const text = value === null || value === undefined ? "" : String(value);
    return /[",\r\n]/.test(text) ? `"${text.replace(/"/g, '""')}"` : text;
  }

  function build(match) {
    if (!match || !Number.isSafeInteger(match.teamCount) || match.teamCount < 0 || !Array.isArray(match.events)) {
      throw new TypeError("유효하지 않은 경기 기록입니다.");
    }

    const startedAt = formatDate(match.startedAt);
    const endedAt = formatDate(match.endedAt);
    const totals = new Map();
    const runningCounts = new Map();
    const detailRows = [];
    for (let index = 0; index < match.events.length; index += 1) {
      const event = match.events[index];
      if (!event || (event.team !== null && (!Number.isSafeInteger(event.team) || event.team < 1 || event.team > match.teamCount))) {
        throw new TypeError("판정의 팀 번호를 확인해 주세요.");
      }
      if (event.at === null || event.at === undefined) {
        throw new TypeError("판정 시각이 없습니다.");
      }
      const timestamp = formatDate(event.at);
      const cumulativeCount = (runningCounts.get(event.team) || 0) + 1;
      runningCounts.set(event.team, cumulativeCount);
      totals.set(event.team, cumulativeCount);
      detailRows.push([
        "판정", match.teamCount, event.team === null ? "미지정" : `${event.team}팀`,
        cumulativeCount, index + 1, timestamp, startedAt, endedAt,
      ]);
    }

    const rows = [HEADERS];
    for (let team = 1; team <= match.teamCount; team += 1) {
      rows.push(["팀별 집계", match.teamCount, `${team}팀`, totals.get(team) || 0, "", "", startedAt, endedAt]);
    }
    if (totals.has(null) || match.teamCount === 0) {
      rows.push(["팀별 집계", match.teamCount, "미지정", totals.get(null) || 0, "", "", startedAt, endedAt]);
    }
    // The BOM makes Korean text readable when opening the CSV directly in Excel.
    return "\uFEFF" + rows.concat(detailRows).map((row) => row.map(cell).join(",")).join("\r\n") + "\r\n";
  }

  function filename(match) {
    const parts = dateParts(match.endedAt ?? match.startedAt);
    if (!parts) return "침범기록.csv";
    const [year, month, day, hour, minute, second] = parts;
    return `침범기록_${year}${month}${day}_${hour}${minute}${second}.csv`;
  }

  function download(match) {
    const csv = build(match);
    const name = filename(match);
    const url = URL.createObjectURL(new Blob([csv], { type: "text/csv;charset=utf-8" }));
    const link = document.createElement("a");
    link.href = url;
    link.download = name;
    link.hidden = true;
    try {
      document.body.append(link);
      link.click();
    } finally {
      link.remove();
      // Give browsers time to start reading the blob before releasing it.
      window.setTimeout(() => URL.revokeObjectURL(url), 60_000);
    }
    return name;
  }

  window.RefereeCsv = Object.freeze({ build, filename, download });
})();
