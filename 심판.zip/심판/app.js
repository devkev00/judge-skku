(() => {
  "use strict";

  const STORAGE_KEY = "referee.matches.v2";
  const LEGACY_KEY = "referee.infringement.v1";
  const MAX_TEAMS = 100;
  const VOICE_FILES = Object.freeze({
    female: "assets/intrusion-female.mp3",
    male: "assets/intrusion-male.mp3",
    original: "assets/intrusion.mp3",
  });
  const $ = (id) => document.getElementById(id);
  const voice = $("voice");
  const clockFormat = new Intl.DateTimeFormat("ko-KR", {
    hour: "2-digit", minute: "2-digit", second: "2-digit", hourCycle: "h23",
  });
  const fullDateFormat = new Intl.DateTimeFormat("ko-KR", {
    year: "numeric", month: "2-digit", day: "2-digit",
    hour: "2-digit", minute: "2-digit", second: "2-digit", hourCycle: "h23",
  });
  const settings = { soundEnabled: true, volume: 80, voicePreset: "female" };
  let match = null;
  let legacyEvents = [];
  let selectedTeam = 1;
  let setupMode = false;
  let pendingAnnouncements = 0;
  let speaking = false;
  let playbackVersion = 0;
  let audioError = "";
  let playbackTimeout;
  let pressTimeout;

  const validTime = (value) => Number.isSafeInteger(value) && value >= 0 && value <= 8640000000000000;
  const validTeamCount = (value) => Number.isInteger(value) && value >= 1 && value <= MAX_TEAMS;
  const isRunning = () => match?.status === "running" && !setupMode;

  function storageError(message) {
    $("storage-status").classList.add("error");
    $("storage-status-text").textContent = message;
  }

  function readSettings(saved) {
    if (!saved || typeof saved !== "object") return;
    if (typeof saved.soundEnabled === "boolean") settings.soundEnabled = saved.soundEnabled;
    if (Number.isInteger(saved.volume) && saved.volume >= 10 && saved.volume <= 100) settings.volume = saved.volume;
    if (Object.prototype.hasOwnProperty.call(VOICE_FILES, saved.voicePreset)) settings.voicePreset = saved.voicePreset;
  }

  function validMatch(saved) {
    return saved && validTeamCount(saved.teamCount) && validTime(saved.startedAt)
      && ["running", "finished"].includes(saved.status)
      && (saved.status === "running" ? saved.endedAt === null : validTime(saved.endedAt))
      && Array.isArray(saved.events)
      && saved.events.every((event) => event && Number.isInteger(event.team)
        && event.team >= 1 && event.team <= saved.teamCount && validTime(event.at));
  }

  // Keep unassigned records from the earlier version available as a separate CSV.
  try {
    const legacy = JSON.parse(localStorage.getItem(LEGACY_KEY) || "null");
    if (legacy && Array.isArray(legacy.events) && legacy.events.every(validTime)) {
      legacyEvents = legacy.events;
      readSettings(legacy);
    }
  } catch {
    storageError("이전 기록을 불러오지 못했습니다.");
  }

  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      const saved = JSON.parse(raw);
      if (!saved || (saved.match !== null && !validMatch(saved.match))) throw new Error("Invalid match");
      readSettings(saved.settings);
      match = saved.match;
      if (match && Number.isInteger(saved.selectedTeam) && saved.selectedTeam >= 1 && saved.selectedTeam <= match.teamCount) {
        selectedTeam = saved.selectedTeam;
      }
    }
  } catch {
    storageError("저장된 경기를 불러오지 못했습니다. 팀 수를 다시 입력하세요.");
  }

  function save() {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify({ settings, match, selectedTeam }));
      $("storage-status").classList.remove("error");
      $("storage-status-text").textContent = "이 브라우저에 자동 저장";
    } catch {
      storageError("자동 저장 실패. 창을 닫기 전에 결과 화면에서 CSV를 내려받으세요.");
    }
  }

  function teamTotals() {
    const totals = Array(match.teamCount).fill(0);
    for (const event of match.events) totals[event.team - 1] += 1;
    return totals;
  }

  function renderRunning() {
    const totals = teamTotals();
    const currentCount = totals[selectedTeam - 1].toLocaleString("ko-KR");
    $("match-team-count").textContent = match.teamCount;
    $("current-team").textContent = `${selectedTeam}팀`;
    $("count").textContent = currentCount;
    $("count").dataset.digits = currentCount.length;
    $("count").setAttribute("aria-label", `${selectedTeam}팀 침범 횟수`);
    $("record-button").setAttribute("aria-label", `${selectedTeam}팀 침범 1회 추가`);
    $("prev-team").disabled = selectedTeam === 1;
    $("next-team").disabled = selectedTeam === match.teamCount;
    $("match-started").textContent = fullDateFormat.format(match.startedAt);
    $("match-started").dateTime = new Date(match.startedAt).toISOString();
    $("undo-button").disabled = match.events.length === 0;
    $("reset-button").disabled = match.events.length === 0;
    const currentEvents = match.events.filter((event) => event.team === selectedTeam);
    $("empty-history").hidden = currentEvents.length > 0;
    $("history").hidden = currentEvents.length === 0;
    $("history-title").textContent = `${selectedTeam}팀 최근 판정`;
    const rows = currentEvents.slice(-5).reverse().map((event, index) => {
      const row = document.createElement("li");
      row.className = "history-row";
      const number = document.createElement("span");
      number.className = "history-number";
      number.textContent = currentEvents.length - index;
      const label = document.createElement("span");
      label.className = "history-name";
      label.textContent = "침범";
      const time = document.createElement("time");
      time.dateTime = new Date(event.at).toISOString();
      time.textContent = clockFormat.format(event.at);
      time.title = fullDateFormat.format(event.at);
      row.append(number, label, time);
      return row;
    });
    $("history").replaceChildren(...rows);
  }

  function renderResult() {
    $("result-team-count").textContent = match.teamCount;
    $("result-started").textContent = fullDateFormat.format(match.startedAt);
    $("result-ended").textContent = fullDateFormat.format(match.endedAt);
    const rows = teamTotals().map((total, index) => {
      const row = document.createElement("tr");
      const team = document.createElement("th");
      team.scope = "row";
      team.textContent = `${index + 1}팀`;
      const count = document.createElement("td");
      count.textContent = total;
      row.append(team, count);
      return row;
    });
    $("result-rows").replaceChildren(...rows);
  }

  function render() {
    const setup = !match || setupMode;
    const running = !setup && match.status === "running";
    $("setup-view").hidden = !setup;
    $("match-view").hidden = !running;
    $("result-view").hidden = setup || running;
    $("phase-label").textContent = setup ? "경기 설정" : running ? "판정 중" : "경기 결과";
    document.body.classList.toggle("is-scoreboard", running);
    document.body.classList.toggle("is-results", !setup && !running);
    $("legacy-records").hidden = legacyEvents.length === 0;
    $("legacy-count").textContent = legacyEvents.length;
    $("back-to-result").hidden = !setupMode || match?.status !== "finished";
    if (running) renderRunning();
    else if (!setup) renderResult();
  }

  function renderAudio() {
    $("sound-toggle").setAttribute("aria-checked", String(settings.soundEnabled));
    $("volume").disabled = !settings.soundEnabled;
    $("preview-button").disabled = !settings.soundEnabled;
    $("voice-preset").disabled = !settings.soundEnabled;
    $("voice-preset").value = settings.voicePreset;
    $("volume").value = settings.volume;
    $("volume-value").textContent = `${settings.volume}%`;
    const position = ((settings.volume - 10) / 90) * 100;
    $("volume").style.backgroundImage = `linear-gradient(to right, #7e8e6e ${position}%, #edf0e7 ${position}%)`;
    $("audio-status").classList.toggle("off", !settings.soundEnabled);
    $("audio-status").classList.toggle("error", Boolean(audioError && settings.soundEnabled));
    $("audio-status-text").textContent = !settings.soundEnabled ? "음성 꺼짐"
      : audioError || (speaking ? "“침범” 재생 중" : "음성 켜짐");
  }

  function stopVoice() {
    clearTimeout(playbackTimeout);
    playbackVersion += 1;
    pendingAnnouncements = 0;
    speaking = false;
    voice.pause();
    voice.currentTime = 0;
    renderAudio();
  }

  function reportAudioError(message = "음성 재생 실패. 미리 듣기로 다시 시도하세요.") {
    audioError = message;
    stopVoice();
  }

  function playNext() {
    if (!settings.soundEnabled || speaking || pendingAnnouncements === 0) return;
    pendingAnnouncements -= 1;
    speaking = true;
    audioError = "";
    voice.currentTime = 0;
    voice.volume = settings.volume / 100;
    const attempt = ++playbackVersion;
    renderAudio();
    playbackTimeout = setTimeout(() => {
      if (attempt === playbackVersion) reportAudioError("재생이 멈췄습니다. 출력 장치와 음소거를 확인하세요.");
    }, 4000);
    voice.play().catch(() => {
      if (attempt === playbackVersion) reportAudioError();
    });
  }

  function announce() {
    if (!settings.soundEnabled) return;
    pendingAnnouncements += 1;
    playNext();
  }

  voice.addEventListener("ended", () => {
    clearTimeout(playbackTimeout);
    speaking = false;
    playNext();
    renderAudio();
  });
  voice.addEventListener("error", () => reportAudioError());

  function record(team) {
    if (!isRunning() || document.querySelector("dialog[open]")
      || !Number.isInteger(team) || team < 1 || team > match.teamCount) return;
    match.events.push({ team, at: Date.now() });
    selectedTeam = team;
    renderRunning();
    save();
    announce();
    const total = match.events.filter((event) => event.team === team).length;
    $("announcement").textContent = `${team}팀 침범 ${total}회`;
    const scoreboard = $("scoreboard");
    scoreboard.classList.add("recorded");
    clearTimeout(pressTimeout);
    pressTimeout = setTimeout(() => scoreboard.classList.remove("recorded"), 180);
  }

  function downloadCsv() {
    if (match?.status !== "finished") return;
    try {
      const filename = window.RefereeCsv.download(match);
      $("csv-status").textContent = `CSV 다운로드 요청: ${filename}`;
      $("csv-status").classList.remove("error");
    } catch {
      $("csv-status").textContent = "다운로드하지 못했습니다. 결과 다운로드를 다시 눌러주세요.";
      $("csv-status").classList.add("error");
    }
  }

  function undoLast() {
    if (!isRunning() || match.events.length === 0) return;
    const removed = match.events.pop();
    selectedTeam = removed.team;
    stopVoice();
    renderRunning();
    save();
    $("announcement").textContent = `${removed.team}팀 마지막 판정 취소`;
    $("record-button").focus();
  }

  $("setup-form").addEventListener("submit", (event) => {
    event.preventDefault();
    if (isRunning()) return;
    const teamCount = $("team-count").valueAsNumber;
    if (!validTeamCount(teamCount)) {
      $("team-count-error").textContent = `팀 수는 1~${MAX_TEAMS} 사이의 정수로 입력하세요.`;
      $("team-count-error").hidden = false;
      $("team-count").setAttribute("aria-invalid", "true");
      $("team-count").focus();
      return;
    }
    $("team-count-error").hidden = true;
    $("team-count").removeAttribute("aria-invalid");
    match = { teamCount, startedAt: Date.now(), endedAt: null, status: "running", events: [] };
    setupMode = false;
    selectedTeam = 1;
    $("csv-status").textContent = "";
    stopVoice();
    save();
    render();
    $("record-button").focus();
    $("announcement").textContent = `${teamCount}팀 경기 시작`;
  });

  function changeTeam(direction) {
    if (!isRunning() || document.querySelector("dialog[open]")) return;
    const nextTeam = selectedTeam + direction;
    if (nextTeam < 1 || nextTeam > match.teamCount) return;
    selectedTeam = nextTeam;
    stopVoice();
    renderRunning();
    save();
    $("record-button").focus();
    $("announcement").textContent = `${selectedTeam}팀, 침범 ${teamTotals()[selectedTeam - 1]}회`;
  }

  $("record-button").addEventListener("click", () => record(selectedTeam));
  $("prev-team").addEventListener("click", () => changeTeam(-1));
  $("next-team").addEventListener("click", () => changeTeam(1));
  $("undo-button").addEventListener("click", undoLast);

  $("reset-button").addEventListener("click", () => {
    if (!isRunning() || match.events.length === 0) return;
    $("settings-dialog").close();
    $("reset-dialog").returnValue = "";
    $("reset-dialog").showModal();
  });
  $("reset-form").addEventListener("submit", (event) => {
    if (event.submitter?.value !== "confirm") return;
    event.preventDefault();
    $("reset-dialog").close("confirm");
    if (!isRunning()) return;
    match.events = [];
    stopVoice();
    renderRunning();
    save();
    $("record-button").focus();
    $("announcement").textContent = "모든 팀의 판정 기록 초기화";
  });

  $("show-results-button").addEventListener("click", () => {
    if (!isRunning()) return;
    match.status = "finished";
    match.endedAt = Date.now();
    $("csv-status").textContent = "";
    $("csv-status").classList.remove("error");
    stopVoice();
    save();
    render();
    $("result-title").focus();
    $("announcement").textContent = "팀별 경기 결과";
  });
  $("resume-button").addEventListener("click", () => {
    if (match?.status !== "finished") return;
    match.status = "running";
    match.endedAt = null;
    setupMode = false;
    stopVoice();
    save();
    render();
    $("record-button").focus();
  });
  $("download-button").addEventListener("click", downloadCsv);
  $("new-match-button").addEventListener("click", () => {
    if (match?.status !== "finished") return;
    setupMode = true;
    $("team-count").value = match.teamCount;
    $("team-count-error").hidden = true;
    $("team-count").removeAttribute("aria-invalid");
    render();
    $("team-count").focus();
    $("team-count").select();
  });
  $("back-to-result").addEventListener("click", () => {
    if (match?.status !== "finished") return;
    setupMode = false;
    render();
    $("download-button").focus();
  });
  $("legacy-download").addEventListener("click", () => {
    if (!legacyEvents.length) return;
    try {
      window.RefereeCsv.download({
        teamCount: 0, startedAt: null, endedAt: null,
        events: legacyEvents.map((at) => ({ team: null, at })),
      });
      $("legacy-download").textContent = "이전 기록 CSV 다시 받기";
    } catch {
      storageError("이전 기록 CSV 다운로드 실패. 다시 시도하세요.");
    }
  });

  $("preview-button").addEventListener("click", announce);
  $("voice-preset").addEventListener("change", (event) => {
    if (!Object.prototype.hasOwnProperty.call(VOICE_FILES, event.target.value)) return;
    const selected = event.target.value;
    stopVoice();
    settings.voicePreset = selected;
    audioError = "";
    voice.src = VOICE_FILES[selected];
    voice.load();
    renderAudio();
    save();
  });
  $("sound-toggle").addEventListener("click", () => {
    settings.soundEnabled = !settings.soundEnabled;
    if (!settings.soundEnabled) stopVoice();
    renderAudio();
    save();
  });
  $("volume").addEventListener("input", (event) => {
    settings.volume = Number(event.target.value);
    voice.volume = settings.volume / 100;
    renderAudio();
    save();
  });

  $("settings-button").addEventListener("click", () => {
    if (isRunning()) $("settings-dialog").showModal();
  });
  $("close-settings").addEventListener("click", () => $("settings-dialog").close());
  $("settings-dialog").addEventListener("close", () => {
    if (isRunning() && !$("reset-dialog").open) $("record-button").focus();
  });

  $("fullscreen-button").hidden = typeof document.documentElement.requestFullscreen !== "function";
  $("fullscreen-button").addEventListener("click", async () => {
    try {
      if (document.fullscreenElement) await document.exitFullscreen();
      else await document.documentElement.requestFullscreen();
      $("screen-status").textContent = "";
    } catch {
      $("screen-status").textContent = "전체 화면을 열지 못했습니다. 브라우저의 전체 화면 기능을 사용하세요.";
    }
  });
  document.addEventListener("fullscreenchange", () => {
    const label = document.fullscreenElement ? "전체 화면 해제" : "전체 화면";
    $("fullscreen-button").querySelector("span").textContent = label;
    $("fullscreen-button").setAttribute("aria-label", label);
  });

  document.addEventListener("keydown", (event) => {
    if (!isRunning() || event.isComposing || event.altKey || event.ctrlKey || event.metaKey
      || document.querySelector("dialog[open]")) return;
    const target = event.target;
    if (target.isContentEditable || target.closest("input, textarea, select, [contenteditable]")) return;
    if (event.code === "Backspace") {
      event.preventDefault();
      if (!event.repeat) undoLast();
      return;
    }
    if (event.code === "ArrowLeft" || event.code === "ArrowRight") {
      event.preventDefault();
      if (!event.repeat) changeTeam(event.code === "ArrowLeft" ? -1 : 1);
      return;
    }
    if (event.code !== "Space") return;
    if (target.closest("button, a, [role='button'], [role='switch']")) {
      if (event.repeat && target.closest("#record-button")) event.preventDefault();
      return;
    }
    event.preventDefault();
    if (!event.repeat) record(selectedTeam);
  });

  voice.src = VOICE_FILES[settings.voicePreset];
  render();
  renderAudio();
})();
